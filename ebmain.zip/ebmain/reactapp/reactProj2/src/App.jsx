import { useState } from 'react'
import './App.css'
import BooksDisplay from './components/BooksDisplay'
import BookForm from './components/BookForm'

function App() {
  const [add, setAdd] = useState(false)

  const checkAdd = (status)=>{
    setAdd(status);
    console.log(add);
  }

  return (
    <>
      <BookForm addBook={checkAdd}/>
      <BooksDisplay status = {add}/>
    </>
  )
}

export default App
