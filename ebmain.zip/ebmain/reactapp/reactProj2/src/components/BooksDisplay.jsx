import axios from 'axios';
import { useState } from 'react'
import { useEffect } from 'react';
import PropTypes from 'prop-types'
 
function BooksDisplay({ status }) {

    const [books, setBooks] = useState([]);

    const handleRefresh = () => {
        axios.get('http://localhost:3001/books/listAll')
        .then(res => {
            setBooks(res.data);
        })
        .catch(err => {
            console.log(err);
        })
    }

    useEffect(()=>{
        handleRefresh();
    },[status])

  return (
    <div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>AUTHOR</th>
                    <th>PRICE</th>
                </tr>
            </thead>
            <tbody>
                {
                    books.map((book,index) => {
                        return (
                            <tr key={index}>
                                <td>{book.id}</td>
                                <td>{book.name}</td>
                                <td>{book.author}</td>
                                <td>{book.price}</td>
                            </tr>
                        )
                    })
                }
            </tbody>
        </table>
    </div>
  )
}

BooksDisplay.propTypes = {
    status : PropTypes.bool.isRequired,
};

export default BooksDisplay