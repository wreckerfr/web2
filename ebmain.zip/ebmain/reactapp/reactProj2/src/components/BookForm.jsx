import { useState } from 'react'
import axios from 'axios';
import PropTypes from 'prop-types'

function BookForm({ addBook }) {

    const [name, setName] = useState("");
    const [author, setAuthor] = useState("");
    const [price, setPrice] = useState(0);

    const handleSubmit = (e) => {
        e.preventDefault();
        const book = {
            name: name,
            author: author,
            price: Number(price)
        }
        axios.post('http://localhost:3001/books/add', book)
            .then((response) => {
                console.log(response.data);
                alert("Book Added");
                addBook(true);
            })
            .catch((error) => {
                console.error(error);
                alert("Error");
            });
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <table>
                    <tr>
                        <td>
                            <label htmlFor="bookName">Name:</label>
                            <input id='bookName' type="text" value={name} onChange={e => setName(e.target.value)} />
                        </td>
                        <td>
                            <label htmlFor="bookAuthor">Author:</label>
                            <input id='bookAuthor' type="text" value={author} onChange={e => setAuthor(e.target.value)} />
                        </td>
                        <td>
                            <label htmlFor="bookPrice">Price:</label>
                            <input id='bookPrice' type="number" value={price} onChange={e => setPrice(e.target.value)} />
                        </td>
                        <td>
                            <button id='addBookButton' type='submit' >Add</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    )
}

BookForm.propTypes ={
    addBook : PropTypes.func.isRequired,
};

export default BookForm;