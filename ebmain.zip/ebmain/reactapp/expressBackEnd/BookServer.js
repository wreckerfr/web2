const express = require('express')
const app = express()
const bodyParser = require('body-parser')

app.use(bodyParser.json());

let id = 0;
let books = [];

app.get('/books/listAll',(req,res)=>{
    res.json(books);
});

app.post('/books/add',(req,resp)=>{
    let {name, author, price} = req.body;
    const newBook = {
        id : id++,
        name,
        author,
        price
    };
    books.push(newBook);
    resp.status(201).json(newBook);
});

app.listen(3001,()=>{
    console.log('server is running on port 3001');
})