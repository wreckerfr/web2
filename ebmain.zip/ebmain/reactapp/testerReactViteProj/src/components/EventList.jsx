import PropTypes from 'prop-types';

const EventList = ({events})=>{
  
    return (
    <>
    <div>EventList</div>
    <ul>
        {events.map((event,index)=>(

            <li key={index}>
                <h3>{event.title}</h3>
                <p>{event.desc}</p>
                <h3>Due Date:{event.dueDate}</h3>
            </li>
        ))}
    </ul>
    </>
  )
}

EventList.propTypes = {
    events: PropTypes.func.isRequired,
  };

export default EventList