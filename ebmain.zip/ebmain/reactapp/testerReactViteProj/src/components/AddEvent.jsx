import { useState } from 'react'
import PropTypes from 'prop-types';

const AddEvent = ({onAddEvent})=>{
  
    const [title , setTitle] = useState('');
    const [desc , setDesc] = useState('');
    const [dueDate , setDueDate] = useState('');

    const handleSubmit = (e)=>{
        e.preventDefault();
        if (title && desc && dueDate){
            onAddEvent({title , desc, dueDate});
            setTitle('');
            setDesc('');
            setDueDate('');
        }

    };


  return (
    <>
    <div className='container'>AddEvent</div>
    <form className='form' onSubmit={handleSubmit}>
        <label htmlFor="title">Title:</label>
        <input id='title' type="text" value={title} onChange={(e)=>setTitle(e.target.value)}/>
        <br/>
        <label htmlFor="desc">Description:</label>
        <textarea id='desc' type="text" value={desc} onChange={(e)=>setDesc(e.target.value)}/>
        <br/>
        <label htmlFor="dueDate"></label>
        <input id="dueDate" type="date" value={dueDate} onChange={(e)=>setDueDate(e.target.value)}/>
        <br/>
        <button type='submit'>Add Event</button>
    </form>
    </>
  )
}

AddEvent.propTypes = {
    onAddEvent: PropTypes.func.isRequired,
  };

export default AddEvent