import { useState } from 'react'
import AddEvent from './components/AddEvent'
import EventList from './components/EventList'
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  const [events, setEvents] = useState([]);

  const handleAddEvent = (event) => {
    setEvents([...events, event]);
  }

  return (
    <>
    <div className='container'>
      <AddEvent onAddEvent={handleAddEvent}/>
    </div>
    <div className='container'>
      <EventList events={events} />
    </div>
    </>
  )
}

export default App
