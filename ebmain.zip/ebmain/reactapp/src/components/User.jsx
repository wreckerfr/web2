import React from 'react'

export default function User(props) {

    const handleDelete = () => {
        props.onDelete(props.user.id);
    }

    const handleUpdate = () => {
        props.onUpdate(props.user.id)
    }

  return (
    <div>
        <span>{props.user.id}</span>
        <span>{props.user.name}</span>
        <span>{props.user.role}</span>
        <button onClick={handleDelete}>DELETE</button>
        <button onClick={handleUpdate}>UPDATE</button>
    </div>
  )
}
