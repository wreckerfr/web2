import React from 'react'

export default function Testcomponent() {
  return (
    <div>this is a tester component</div>
    <div>this is the sec</div>
  )
}
