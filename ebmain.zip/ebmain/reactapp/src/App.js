import logo from "./logo.svg";
import "./App.css";
import { useState } from "react";
import User from "./components/User";

function App() {
  const [users, setUsers] = useState([
    { id: 1, name: "abc", role: "admin" },
    { id: 2, name: "bcv", role: "user" },
    { id: 4, name: "pls", role: "user" },
  ]);

  // let counter = 1;

  const [name, setName] = useState("");
  //const [id,setId] = useState(null);
  const [role, setRole] = useState("");

  const handleAddUser = ()=>{
    if (!name || !role) {
      return;
    }
    let sid = 1;
    for(let u of users){
      if(u.id === sid){
        sid = u.id+1;
      }
    }
    let sortedArray = [...users,{ id : sid , name, role }];
    let fSorted = sortedArray.sort((u1,u2)=>{return u1.id - u2.id});
    setUsers(fSorted);
    setName("");
    setRole("");
  }

  const handleDeleteUser = (ID)=>{
    
    const updatedUsers = users.filter((user) => user.id !== ID);
    setUsers(updatedUsers);
    // let index;
    // if(users.filter((user)=>{
    //   if(user.id === counter){
    //     index = users.findIndex((user1=>user1.id === ID))
    //     return user;
    //   }
    // }).length > 0){
    //   users.splice(index,1);
    // }else{
    //   return;
    // }
  }

  const handleUpdateUser = (ID)=>{

    const upUser = users.filter((user => user.id === ID))
    upUser.

  }

  return (
  <div className="App">
    <h2>CRUD OPERATIONS</h2>
    <div>
    <input type="text" value={name} placeholder="Name" onChange={(e)=>setName(e.target.value)}></input>
    <input type="text" value={role} placeholder="Role" onChange={(e)=>setRole(e.target.value)}></input>
    <button onClick={handleAddUser}>ADD USER</button>
    </div>
    <div className="Displaydiv">
      {users.map((user)=>(
        <User
        key={user.id}
        user = {user}
        onDelete = {handleDeleteUser}
        onUpdate = {handleUpdateUser}
        />
      ))}
    </div>
  </div>
  );
}

export default App;
