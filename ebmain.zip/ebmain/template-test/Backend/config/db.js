const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    //MySQL user-name 
    user: 'root',
        //MySQL password 
    password: 'root',
    //MySQL database name
    database: 'employee_db'
});


/*
    If you have a MySQL database named 'employee_db', you can use the following code:
    
*/


db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL Is Connected');
});

module.exports = db;
