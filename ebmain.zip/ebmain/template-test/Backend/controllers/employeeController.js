const Employee = require('../models/employeeModel');

exports.getAllEmployees = (req, res) => {
    Employee.getAll((err, data) => {
        if (err) {
            res.status(500).send({
                message: err.message || 'Some error occurred while retrieving employees.'
            });
        } else {
            res.send(data);
        }
    });
};

exports.createEmployee = (req, res) => {
    const newEmployee = {
        name: req.body.name,
        position: req.body.position,
        salary: req.body.salary
    };

    Employee.create(newEmployee, (err, data) => {
        if (err) {
            res.status(500).send({
                message: err.message || 'Some error occurred while creating the employee.'
            });
        } else {
            res.send(data);
        }
    });
};

exports.updateEmployee = (req, res) => {
    const employee = {
        name: req.body.name,
        position: req.body.position,
        salary: req.body.salary
    };

    Employee.updateById(req.params.id, employee, (err, data) => {
        if (err) {
            res.status(500).send({
                message: err.message || 'Some error occurred while updating the employee.'
            });
        } else {
            res.send(data);
        }
    });
};

exports.deleteEmployee = (req, res) => {
    Employee.delete(req.params.id, (err, data) => {
        if (err) {
            res.status(500).send({
                message: err.message || 'Some error occurred while deleting the employee.'
            });
        } else {
            res.send({ message: 'Employee deleted successfully!' });
        }
    });
};
