const db = require('../config/db');

const Employee = {};

Employee.getAll = (result) => {
    db.query('SELECT * FROM employees', (err, res) => {
        if (err) {
            console.log('Error: ', err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};

Employee.create = (newEmployee, result) => {
    db.query('INSERT INTO employees SET ?', newEmployee, (err, res) => {
        if (err) {
            console.log('Error: ', err);
            result(null, err);
        } else {
            result(null, { id: res.insertId, ...newEmployee });
        }
    });
};

Employee.updateById = (id, employee, result) => {
    db.query('UPDATE employees SET ? WHERE id = ?', [employee, id], (err, res) => {
        if (err) {
            console.log('Error: ', err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};

Employee.delete = (id, result) => {
    db.query('DELETE FROM employees WHERE id = ?', id, (err, res) => {
        if (err) {
            console.log('Error: ', err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};

module.exports = Employee;
