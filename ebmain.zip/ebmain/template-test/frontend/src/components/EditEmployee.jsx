import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EditEmployee = ({ match, history }) => {
    const [name, setName] = useState('');
    const [position, setPosition] = useState('');
    const [salary, setSalary] = useState('');

    useEffect(() => {
        axios.get(`http://localhost:5000/api/employees/${match.params.id}`)
            .then(res => {
                setName(res.data.name);
                setPosition(res.data.position);
                setSalary(res.data.salary);
            })
            .catch(err => console.log(err));
    }, [match.params.id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`http://localhost:5000/api/employees/${match.params.id}`, { name, position, salary })
            .then(() => {
                history.push('/');
            })
            .catch(err => console.log(err));
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Name:</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
                <label>Position:</label>
                <input type="text" value={position} onChange={(e) => setPosition(e.target.value)} />
            </div>
            <div>
                <label>Salary:</label>
                <input type="text" value={salary} onChange={(e) => setSalary(e.target.value)} />
            </div>
            <button type="submit">Update Employee</button>
        </form>
    );
};

export default EditEmployee;
