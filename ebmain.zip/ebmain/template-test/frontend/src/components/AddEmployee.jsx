import React, { useState } from 'react';
import axios from 'axios';

const AddEmployee = ({ history }) => {
    const [name, setName] = useState('');
    const [position, setPosition] = useState('');
    const [salary, setSalary] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:5000/api/employees', { name, position, salary })
            .then(() => {
                history.push('/');
            })
            .catch(err => console.log(err));
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Name:</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
                <label>Position:</label>
                <input type="text" value={position} onChange={(e) => setPosition(e.target.value)} />
            </div>
            <div>
                <label>Salary:</label>
                <input type="text" value={salary} onChange={(e) => setSalary(e.target.value)} />
            </div>
            <button type="submit">Add Employee</button>
        </form>
    );
};

export default AddEmployee;
