import React, { useState } from 'react';
import BlogForm from './components/BlogForm';
import BlogList from './components/BlogList';
import { Container, Row, Col } from 'react-bootstrap';

const App = () => {
    const [blogs, setBlogs] = useState([]);
    const [nextId, setNextId] = useState(1);

    const addBlog = (blog) => {
        setBlogs([...blogs, { ...blog, id: nextId }]);
        setNextId(nextId + 1);
    };

    const deleteBlog = (id) => {
        setBlogs(blogs.filter(blog => blog.id !== id));
    };

    return (
        <Container className="mt-4">
            <Row>
                <Col md={6} className="mx-auto">
                    <h1 className="text-center mb-4">My Blog</h1>
                    <BlogForm addBlog={addBlog} />
                    <BlogList blogs={blogs} deleteBlog={deleteBlog} />
                </Col>
            </Row>
        </Container>
    );
};

export default App;
