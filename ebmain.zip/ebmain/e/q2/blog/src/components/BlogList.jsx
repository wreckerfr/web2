import React from 'react';
import BlogItem from './BlogItem';

const BlogList = ({ blogs, deleteBlog }) => {
    return (
        <div>
            {blogs.map((blog) => (
                <BlogItem key={blog.id} blog={blog} onDelete={deleteBlog} />
            ))}
        </div>
    );
};

export default BlogList;
