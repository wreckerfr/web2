import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

const BlogForm = ({ addBlog }) => {
    const [blogName, setBlogName] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (blogName) {
            addBlog({ name: blogName, date: new Date().toLocaleDateString() });
            setBlogName('');
        }
    };

    return (
        <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formBasicBlog">
                <Form.Label>Blog Name</Form.Label>
                <Form.Control
                    type="text"
                    placeholder="Enter blog name"
                    value={blogName}
                    onChange={(e) => setBlogName(e.target.value)}
                />
            </Form.Group>
            <Button variant="primary" type="submit">
                Add Blog
            </Button>
        </Form>
    );
};

export default BlogForm;
