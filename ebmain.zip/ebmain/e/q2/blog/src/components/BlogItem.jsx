import React from 'react';
import { Card, Button } from 'react-bootstrap';

const BlogItem = ({ blog, onDelete }) => {
    return (
        <Card className="mb-3">
            <Card.Body>
                <Card.Title>{blog.name}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">{blog.date}</Card.Subtitle>
                <Button variant="danger" onClick={() => onDelete(blog.id)}>Delete</Button>
            </Card.Body>
        </Card>
    );
};

export default BlogItem;
