const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');

app.use(express.json());

app.get('/books/list', (req, res) => {
  fs.readFile(path.join(__dirname, 'books.json'), 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading data');
      return;
    }
    res.json(JSON.parse(data));
  });
});

app.listen(8080, () => {
  console.log(`Server running at http://localhost:8080`);
});
