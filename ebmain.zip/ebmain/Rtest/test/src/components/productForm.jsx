import React, { useState, useEffect, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const ProductForm = () => {
  const [productId, setProductId] = useState('');
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [unit, setUnit] = useState('dozen');

  const [errors, setErrors] = useState({
    productId: '',
    productName: '',
    price: '',
  });

  // Memoize validateForm using useCallback
  const validateForm = useCallback(() => {
    let valid = true;
    let errors = {};

    if (!productId) {
      errors.productId = 'Product ID cannot be blank';
      valid = false;
    } else {
      errors.productId = '';
    }

    if (productName.length < 4) {
      errors.productName = 'Product name must be at least 4 characters long';
      valid = false;
    } else {
      errors.productName = '';
    }

    if (price <= 0) {
      errors.price = 'Price must be greater than zero';
      valid = false;
    } else {
      errors.price = '';
    }

    setErrors(errors);
    return valid;
  }, [productId, productName, price]);

  // Compute form validity
  const isFormValid = useCallback(() => validateForm(), [validateForm]);

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      alert('Form submitted!');
      // Handle form submission logic here
    }
  };

  useEffect(() => {
    validateForm();
  }, [validateForm]);

  return (
    <div className="container mt-5">
      <h2>Product Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="productId" className="form-label">Product ID:</label>
          <input
            type="text"
            id="productId"
            className={`form-control ${errors.productId ? 'is-invalid' : ''}`}
            value={productId}
            onChange={(e) => {
              setProductId(e.target.value);
              validateForm(); // Validate on change
            }}
          />
          {errors.productId && <div className="invalid-feedback">{errors.productId}</div>}
        </div>

        <div className="mb-3">
          <label htmlFor="productName" className="form-label">Product Name:</label>
          <input
            type="text"
            id="productName"
            className={`form-control ${errors.productName ? 'is-invalid' : ''}`}
            value={productName}
            onChange={(e) => {
              setProductName(e.target.value);
              validateForm(); // Validate on change
            }}
          />
          {errors.productName && <div className="invalid-feedback">{errors.productName}</div>}
        </div>

        <div className="mb-3">
          <label htmlFor="price" className="form-label">Price:</label>
          <input
            type="number"
            id="price"
            className={`form-control ${errors.price ? 'is-invalid' : ''}`}
            value={price}
            onChange={(e) => {
              setPrice(e.target.value);
              validateForm(); // Validate on change
            }}
            min="0.01"
          />
          {errors.price && <div className="invalid-feedback">{errors.price}</div>}
        </div>

        <div className="mb-3">
          <label htmlFor="unit" className="form-label">Unit of Measurement:</label>
          <select
            id="unit"
            className="form-select"
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
          >
            <option value="dozen">Dozen</option>
            <option value="per piece">Per Piece</option>
            <option value="kg">Kg</option>
          </select>
        </div>

        <button
          type="submit"
          className="btn btn-primary"
          disabled={!isFormValid()}
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default ProductForm;
