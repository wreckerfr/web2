import { useState } from 'react';
import ProductForm from './components/productForm';

function App() {

  return (
    <>
      <ProductForm />
    </>
  )
}

export default App
