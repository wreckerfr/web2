$(document).ready(function () {
    // Define image sources for each category
    const images = {
        groceries: [
            'https://plus.unsplash.com/premium_photo-1675814316651-3ce3c6409922?q=80&w=1936&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            'https://plus.unsplash.com/premium_photo-1699293238761-993a897373ea?q=80&w=2082&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
        ],
        beverages: [
            'https://images.unsplash.com/photo-1559839914-17aae19cec71?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            'https://plus.unsplash.com/premium_photo-1676202363503-4f44c507bc60?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8dGVhfGVufDB8fDB8fHww',
            'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?q=80&w=2069&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
        ],
        other: [
            'https://plus.unsplash.com/premium_photo-1672753747124-2bd4da9931fa?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            'https://plus.unsplash.com/premium_photo-1673439304183-8840bd0dc1bf?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
        ]
    };

    // Event handler for dropdown selection change
    $('#categorySelect').on('change', function () {
        const category = $(this).val();
        const imageContainer = $('#imageContainer');

        // Clear existing images
        imageContainer.empty();

        // Check if the category is valid and add corresponding images
        if (category && images[category]) {
            images[category].forEach(src => {
                imageContainer.append(`<div class="col-4 col-md-3 mb-3"><img src="${src}" alt="${category} image" class="img-thumbnail"></div>`);
            });
        }
    });
});